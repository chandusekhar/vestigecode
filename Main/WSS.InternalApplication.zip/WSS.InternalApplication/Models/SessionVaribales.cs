﻿namespace WSS.InternalApplication.Models
{
    public static class SessionVaribales
    {
        public const string AuditPageNumber = "AuditPageNumber";
        public const string AuditListSort = "AuditListSort";
        public const string AuditListSortDirection = "AuditListSortDirection";
        public const string AuditListRowsPerPage = "AuditListRowsPerPage";
    }
}