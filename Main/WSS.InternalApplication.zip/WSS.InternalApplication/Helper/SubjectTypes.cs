﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WSS.InternalApplication.Helper
{
    public static class SubjectTypes
    {
        public static string WebSelfService = "WebSelfService";
    }
}