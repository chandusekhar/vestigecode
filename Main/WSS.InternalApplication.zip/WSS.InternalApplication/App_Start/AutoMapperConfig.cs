﻿namespace WSS.InternalApplication.App_Start
{
    public class AutoMapperConfig
    {
        public static void RegisterMaps()
        {
        }
    }
}