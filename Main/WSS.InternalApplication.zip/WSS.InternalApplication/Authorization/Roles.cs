﻿namespace WSS.InternalApplication.Authorization
{
    /// <summary>
    ///
    /// </summary>
    public class Roles
    {
        /// <summary>
        ///
        /// </summary>
        public const string CSR = "CSR";

        /// <summary>
        ///
        /// </summary>
        public const string CSRAppAdmin = "CSR-Admin App";

        /// <summary>
        ///
        /// </summary>
        public const string IntrcGA = "Customer Account Staff";

        /// <summary>
        ///
        /// </summary>
        public const string IntrcWithRemove = "Bill Administrator";
    }
}